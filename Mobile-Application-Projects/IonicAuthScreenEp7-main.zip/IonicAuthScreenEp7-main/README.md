# IonicAuthScreenEp7
E-COMMERCE APP (Auth Screens with form validation)

Watch the Full Episode on YouTube at https://www.youtube.com/watch?v=vdRYkwImbYQ&list=PLixvNT19uDK6Fk6glTj18ONQRpCAVnY0G&index=4&ab_channel=CodingTechnyks

<img src="https://github.com/Nykz/IonicAuthScreenEp7/blob/main/screenshots/screenshot1.png" width="200" height="400" />
<img src="https://github.com/Nykz/IonicAuthScreenEp7/blob/main/screenshots/screenshot2.png" width="200" height="400" />
<img src="https://github.com/Nykz/IonicAuthScreenEp7/blob/main/screenshots/screenshot3.png" width="200" height="400" />

### Steps to Setup this beautiful E-Commerce App screen in your system

1.Download the zipped project

2.Create a new Ionic 5 project, refer to <a href="https://www.youtube.com/watch?v=hmB2PYraBZk&t=6s&ab_channel=CodingTechnyks">Setup Ionic Project</a> for guidance

3.Unzipped the project somewhere else but not in the created project folder

4.Copy the src file from the unzipped project and paste in the project folder (replace all)

5.Run ionic serve

That's it
